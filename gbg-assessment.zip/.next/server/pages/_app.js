/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./contexts/context.tsx":
/*!******************************!*\
  !*** ./contexts/context.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Context\": () => (/* binding */ Context),\n/* harmony export */   \"ContextProvider\": () => (/* binding */ ContextProvider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({\n    todos: [],\n    add: ()=>{},\n    clearAll: ()=>{},\n    remove: ()=>{},\n    mark: ()=>{}\n});\nconst reducers = (state, action)=>{\n    switch(action.type){\n        case \"ADD\":\n            return {\n                todos: state.todos.concat(action.payload)\n            };\n        case \"CLEAR_ALL\":\n            return {\n                todos: []\n            };\n        case \"REMOVE\":\n            return {\n                todos: state.todos.filter((todo)=>todo.message !== action.payload)\n            };\n        case \"MARK\":\n            return {\n                todos: state.todos.map((todo)=>todo.message !== action.payload ? todo : {\n                        ...todo,\n                        done: !todo.done\n                    })\n            };\n        default:\n            return state;\n    }\n};\nfunction ContextProvider(props) {\n    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducers, {\n        todos: []\n    });\n    const add = (data)=>dispatch({\n            type: \"ADD\",\n            payload: data\n        });\n    const clearAll = ()=>dispatch({\n            type: \"CLEAR_ALL\"\n        });\n    const remove = (data)=>dispatch({\n            type: \"REMOVE\",\n            payload: data\n        });\n    const mark = (data)=>dispatch({\n            type: \"MARK\",\n            payload: data\n        });\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Context.Provider, {\n        value: {\n            todos: state.todos,\n            add,\n            clearAll,\n            remove,\n            mark\n        },\n        ...props\n    }, void 0, false, {\n        fileName: \"D:\\\\gbg-assessment\\\\contexts\\\\context.tsx\",\n        lineNumber: 50,\n        columnNumber: 5\n    }, this);\n}\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb250ZXh0cy9jb250ZXh0LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUFpRDtBQUdqRCxNQUFNRSxPQUFPLGlCQUFHRixvREFBYSxDQUFtQjtJQUM5Q0csS0FBSyxFQUFFLEVBQUU7SUFDVEMsR0FBRyxFQUFFLElBQU0sRUFBRTtJQUNiQyxRQUFRLEVBQUUsSUFBTSxFQUFFO0lBQ2xCQyxNQUFNLEVBQUUsSUFBTSxFQUFFO0lBQ2hCQyxJQUFJLEVBQUUsSUFBTSxFQUFFO0NBQ2YsQ0FBQztBQUVGLE1BQU1DLFFBQVEsR0FBRyxDQUFDQyxLQUFvQyxFQUFFQyxNQUFXLEdBQUs7SUFDdEUsT0FBUUEsTUFBTSxDQUFDQyxJQUFJO1FBQ2pCLEtBQUssS0FBSztZQUNSLE9BQU87Z0JBQ0xSLEtBQUssRUFBRU0sS0FBSyxDQUFDTixLQUFLLENBQUNTLE1BQU0sQ0FBQ0YsTUFBTSxDQUFDRyxPQUFPLENBQUM7YUFDMUM7UUFDSCxLQUFLLFdBQVc7WUFDZCxPQUFPO2dCQUNMVixLQUFLLEVBQUUsRUFBRTthQUNWO1FBQ0gsS0FBSyxRQUFRO1lBQ1gsT0FBTztnQkFDTEEsS0FBSyxFQUFFTSxLQUFLLENBQUNOLEtBQUssQ0FBQ1csTUFBTSxDQUFDQyxDQUFBQSxJQUFJLEdBQUlBLElBQUksQ0FBQ0MsT0FBTyxLQUFLTixNQUFNLENBQUNHLE9BQU8sQ0FBQzthQUNuRTtRQUNILEtBQUssTUFBTTtZQUNULE9BQU87Z0JBQ0xWLEtBQUssRUFBRU0sS0FBSyxDQUFDTixLQUFLLENBQUNjLEdBQUcsQ0FBQ0YsQ0FBQUEsSUFBSSxHQUFJQSxJQUFJLENBQUNDLE9BQU8sS0FBS04sTUFBTSxDQUFDRyxPQUFPLEdBQUdFLElBQUksR0FBRzt3QkFDdEUsR0FBR0EsSUFBSTt3QkFDUEcsSUFBSSxFQUFFLENBQUNILElBQUksQ0FBQ0csSUFBSTtxQkFDakIsQ0FBQzthQUNIO1FBQ0g7WUFDRSxPQUFPVCxLQUFLO0tBQ2Y7Q0FDRjtBQUVELFNBQVNVLGVBQWUsQ0FBQ0MsS0FBVSxFQUFFO0lBQ25DLE1BQU0sS0FBQ1gsS0FBSyxNQUFFWSxRQUFRLE1BQUlwQixpREFBVSxDQUFDTyxRQUFRLEVBQUU7UUFBRUwsS0FBSyxFQUFFLEVBQUU7S0FBRSxDQUFDO0lBRTdELE1BQU1DLEdBQUcsR0FBRyxDQUFDa0IsSUFBbUIsR0FBS0QsUUFBUSxDQUFDO1lBQUVWLElBQUksRUFBRSxLQUFLO1lBQUVFLE9BQU8sRUFBRVMsSUFBSTtTQUFFLENBQUM7SUFFN0UsTUFBTWpCLFFBQVEsR0FBRyxJQUFNZ0IsUUFBUSxDQUFDO1lBQUVWLElBQUksRUFBRSxXQUFXO1NBQUUsQ0FBQztJQUV0RCxNQUFNTCxNQUFNLEdBQUcsQ0FBQ2dCLElBQVksR0FBS0QsUUFBUSxDQUFDO1lBQUVWLElBQUksRUFBRSxRQUFRO1lBQUVFLE9BQU8sRUFBRVMsSUFBSTtTQUFFLENBQUM7SUFFNUUsTUFBTWYsSUFBSSxHQUFHLENBQUNlLElBQVksR0FBS0QsUUFBUSxDQUFDO1lBQUVWLElBQUksRUFBRSxNQUFNO1lBQUVFLE9BQU8sRUFBRVMsSUFBSTtTQUFFLENBQUM7SUFFeEUscUJBQ0UsOERBQUNwQixPQUFPLENBQUNxQixRQUFRO1FBQ2ZDLEtBQUssRUFBRTtZQUNMckIsS0FBSyxFQUFFTSxLQUFLLENBQUNOLEtBQUs7WUFDbEJDLEdBQUc7WUFDSEMsUUFBUTtZQUNSQyxNQUFNO1lBQ05DLElBQUk7U0FDTDtRQUNBLEdBQUdhLEtBQUs7Ozs7O1lBQ1QsQ0FDSDtDQUNGO0FBRWtDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vY29udGV4dHMvY29udGV4dC50c3g/ZWQxZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VSZWR1Y2VyIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IENvbnRleHRJbnRlcmZhY2UsIFRvZG9JbnRlcmZhY2UgfSBmcm9tICcuLi9pbnRlcmZhY2VzJ1xyXG5cclxuY29uc3QgQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8Q29udGV4dEludGVyZmFjZT4oe1xyXG4gIHRvZG9zOiBbXSxcclxuICBhZGQ6ICgpID0+IHt9LFxyXG4gIGNsZWFyQWxsOiAoKSA9PiB7fSxcclxuICByZW1vdmU6ICgpID0+IHt9LFxyXG4gIG1hcms6ICgpID0+IHt9XHJcbn0pXHJcblxyXG5jb25zdCByZWR1Y2VycyA9IChzdGF0ZTogT21pdDxDb250ZXh0SW50ZXJmYWNlLCBcImFkZFwiPiwgYWN0aW9uOiBhbnkpID0+IHtcclxuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICBjYXNlICdBREQnOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRvZG9zOiBzdGF0ZS50b2Rvcy5jb25jYXQoYWN0aW9uLnBheWxvYWQpXHJcbiAgICAgIH1cclxuICAgIGNhc2UgJ0NMRUFSX0FMTCc6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdG9kb3M6IFtdXHJcbiAgICAgIH1cclxuICAgIGNhc2UgJ1JFTU9WRSc6XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdG9kb3M6IHN0YXRlLnRvZG9zLmZpbHRlcih0b2RvID0+IHRvZG8ubWVzc2FnZSAhPT0gYWN0aW9uLnBheWxvYWQpXHJcbiAgICAgIH1cclxuICAgIGNhc2UgJ01BUksnOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIHRvZG9zOiBzdGF0ZS50b2Rvcy5tYXAodG9kbyA9PiB0b2RvLm1lc3NhZ2UgIT09IGFjdGlvbi5wYXlsb2FkID8gdG9kbyA6IHtcclxuICAgICAgICAgIC4uLnRvZG8sXHJcbiAgICAgICAgICBkb25lOiAhdG9kby5kb25lXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlXHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBDb250ZXh0UHJvdmlkZXIocHJvcHM6IGFueSkge1xyXG4gIGNvbnN0IFtzdGF0ZSwgZGlzcGF0Y2hdID0gdXNlUmVkdWNlcihyZWR1Y2VycywgeyB0b2RvczogW10gfSlcclxuXHJcbiAgY29uc3QgYWRkID0gKGRhdGE6IFRvZG9JbnRlcmZhY2UpID0+IGRpc3BhdGNoKHsgdHlwZTogJ0FERCcsIHBheWxvYWQ6IGRhdGEgfSlcclxuXHJcbiAgY29uc3QgY2xlYXJBbGwgPSAoKSA9PiBkaXNwYXRjaCh7IHR5cGU6ICdDTEVBUl9BTEwnIH0pXHJcblxyXG4gIGNvbnN0IHJlbW92ZSA9IChkYXRhOiBzdHJpbmcpID0+IGRpc3BhdGNoKHsgdHlwZTogJ1JFTU9WRScsIHBheWxvYWQ6IGRhdGEgfSlcclxuXHJcbiAgY29uc3QgbWFyayA9IChkYXRhOiBzdHJpbmcpID0+IGRpc3BhdGNoKHsgdHlwZTogJ01BUksnLCBwYXlsb2FkOiBkYXRhIH0pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGV4dC5Qcm92aWRlclxyXG4gICAgICB2YWx1ZT17e1xyXG4gICAgICAgIHRvZG9zOiBzdGF0ZS50b2RvcyxcclxuICAgICAgICBhZGQsXHJcbiAgICAgICAgY2xlYXJBbGwsXHJcbiAgICAgICAgcmVtb3ZlLFxyXG4gICAgICAgIG1hcmtcclxuICAgICAgfX1cclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgLz5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCB7IENvbnRleHQsIENvbnRleHRQcm92aWRlciB9Il0sIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VSZWR1Y2VyIiwiQ29udGV4dCIsInRvZG9zIiwiYWRkIiwiY2xlYXJBbGwiLCJyZW1vdmUiLCJtYXJrIiwicmVkdWNlcnMiLCJzdGF0ZSIsImFjdGlvbiIsInR5cGUiLCJjb25jYXQiLCJwYXlsb2FkIiwiZmlsdGVyIiwidG9kbyIsIm1lc3NhZ2UiLCJtYXAiLCJkb25lIiwiQ29udGV4dFByb3ZpZGVyIiwicHJvcHMiLCJkaXNwYXRjaCIsImRhdGEiLCJQcm92aWRlciIsInZhbHVlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./contexts/context.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _contexts_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/context */ \"./contexts/context.tsx\");\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        globalThis.document.documentElement.classList.add(\"dark\");\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_contexts_context__WEBPACK_IMPORTED_MODULE_3__.ContextProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"D:\\\\gbg-assessment\\\\pages\\\\_app.tsx\",\n            lineNumber: 16,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"D:\\\\gbg-assessment\\\\pages\\\\_app.tsx\",\n        lineNumber: 15,\n        columnNumber: 5\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFBO0FBQ2lDO0FBRUg7QUFFdUI7QUFFckQsU0FBU0UsS0FBSyxDQUFDLEVBQUVDLFNBQVMsR0FBRUMsU0FBUyxHQUFZLEVBQUU7SUFFakRKLGdEQUFTLENBQUMsSUFBTTtRQUNkSyxVQUFVLENBQUNDLFFBQVEsQ0FBQ0MsZUFBZSxDQUFDQyxTQUFTLENBQUNDLEdBQUcsQ0FBQyxNQUFNLENBQUM7S0FDMUQsRUFBRSxFQUFFLENBQUM7SUFFTixxQkFDRSw4REFBQ1IsOERBQWU7a0JBQ2QsNEVBQUNFLFNBQVM7WUFBRSxHQUFHQyxTQUFTOzs7OztnQkFBSTs7Ozs7WUFDWixDQUNuQjtDQUNGO0FBRUQsaUVBQWVGLEtBQUsiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9fYXBwLnRzeD8yZmJlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFByb3BzIH0gZnJvbSAnbmV4dC9hcHAnXHJcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0J1xyXG5cclxuaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXHJcblxyXG5pbXBvcnQgeyBDb250ZXh0UHJvdmlkZXIgfSBmcm9tICcuLi9jb250ZXh0cy9jb250ZXh0J1xyXG5cclxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZ2xvYmFsVGhpcy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZGFyaycpXHJcbiAgfSwgW10pXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGV4dFByb3ZpZGVyPlxyXG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XHJcbiAgICA8L0NvbnRleHRQcm92aWRlcj5cclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE15QXBwIl0sIm5hbWVzIjpbInVzZUVmZmVjdCIsIkNvbnRleHRQcm92aWRlciIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwiZ2xvYmFsVGhpcyIsImRvY3VtZW50IiwiZG9jdW1lbnRFbGVtZW50IiwiY2xhc3NMaXN0IiwiYWRkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();